# LangChain v1.0 – Hands-On Experiments

This repository contains my hands-on exploration of **LangChain v1.0** while building
and testing multiple Generative AI components.

## What this repository covers
- Retrieval Augmented Generation (RAG)
- Dynamic prompt templates
- Runtime model switching
- Custom agent middleware
- Image + text (multimodal) workflows
- Chat-based LLM interfaces

## Why this project
LangChain v1.0 introduced major architectural changes.
This repo documents my practical understanding of those changes
through direct experimentation and implementation.

## Tech Stack
- Python
- LangChain v1.0
- OpenAI / OpenRouter compatible LLM APIs
- FAISS / Vector databases
- Jupyter Notebook

## Notes
This repository is intended for learning and experimentation.
Production-grade implementations of these ideas are built separately
using FastAPI and modular backend architectures.
